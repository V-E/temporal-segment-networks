#!/usr/bin/env bash

wget -O models/bn_inception_rgb_init.caffemodel https://yjxiong.blob.core.windows.net/tsn-init/bn_inception_rgb_init.caffemodel
wget -O models/bn_inception_flow_init.caffemodel https://yjxiong.blob.core.windows.net/tsn-init/bn_inception_flow_init.caffemodel
